export const classes = [
  {
    id: 1,
    subject: 'Maths',
    className: 'Class 9B',
    timing: '9AM to 10AM',
  },
  {
    id: 2,
    subject: 'Science',
    className: 'Class 10A',
    timing: '10AM to 11AM',
  },
  {
    id: 3,
    subject: 'History',
    className: 'Class 8C',
    timing: '11AM to 12PM',
  },
];
